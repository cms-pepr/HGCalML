
def create_prs_indices(asso_idx):
    raise ValueError("create_prs_indices removed, use calc_ragged_shower_indices instead")

def revert_prs(data, sids):
    raise ValueError("revert_prs removed, use MultiBackGather instead")

def CreatePseudoRS(asso_idx, data):
    raise ValueError("CreatePseudoRS removed, use calc_ragged_shower_indices instead")
