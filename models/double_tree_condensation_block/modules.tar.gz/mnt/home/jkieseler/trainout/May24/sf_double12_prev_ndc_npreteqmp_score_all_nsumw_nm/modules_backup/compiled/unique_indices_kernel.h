
#ifndef UNIQUE_INDICES_KERNEL_H
#define UNIQUE_INDICES_KERNEL_H

namespace tensorflow {
namespace functor {

///empty

}  // namespace functor
}  // namespace tensorflow


#endif //UNIQUE_INDICES_KERNEL_H

