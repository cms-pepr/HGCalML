'''
We don't use the keras metrics logic but layers instead.
Keep this file empty with the exception of the empty dict below
'''
global_metrics_list = {}