
'''
We don't use the standard keras loss logic, keep this file empty
'''
global_loss_list = {}
