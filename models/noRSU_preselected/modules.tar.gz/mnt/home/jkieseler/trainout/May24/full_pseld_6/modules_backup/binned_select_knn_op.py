
import tensorflow as tf
from tensorflow.python.framework import ops
import globals as gl
from oc_helper_ops import SelectWithDefault

from bin_by_coordinates_op import BinByCoordinates
from index_replacer_op import IndexReplacer

_binned_select_knn = tf.load_op_library('binned_select_knn.so')

def _BinnedSelectKnn(K : int, coords,  bin_idx, dim_bin_idx, bin_boundaries, n_bins, bin_width , tf_compatible=False,
                     direction = None):
    '''
    the op wrapper only
    '''
    if direction is None:
        direction = tf.constant([],dtype='int32')
        use_direction=False
    else:
        use_direction=True
    
    return _binned_select_knn.BinnedSelectKnn(n_neighbours=K, 
                                              coords=coords,
                                              bin_idx=bin_idx,
                                              dim_bin_idx=dim_bin_idx,
                                              bin_boundaries=bin_boundaries,
                                              n_bins=n_bins,
                                              bin_width=bin_width,
                                              tf_compatible=tf_compatible,
                                              direction=direction,
                                              use_direction = use_direction
                                              )

#@tf.function
def BinnedSelectKnn(K : int, coords, row_splits, direction = None, n_bins=None, max_bin_dims : int =3 , tf_compatible=False, max_radius=None, name=""):
    '''
    max_radius is a dummy for now to make it a drop-in replacement
    
    0: can only be neighbour, 1: can only have neighbour, 2: neither
    
    direction, if provided, has the following options:
    - 0: can only be neighbour
    - 1: can only have neighbours
    - 2: cannot be neighbour or have neighbours
    - any other number: can be neighbour and have neighbours
    
    '''
    
    # the following number of bins seems a good~ish estimate for good performance
    # for homogenous point distributions but should be subject to more tests
    elems_per_rs = tf.reduce_max(row_splits) / tf.shape(row_splits)[0]
    elems_per_rs = tf.cast(elems_per_rs, dtype='int32')+1
    #if row_splits.shape[0] is not None:
    #    elems_per_rs = row_splits[1]
    #    #do checks
    #    tf.assert_equal(row_splits[-1],coords.shape[0])
        
    max_bin_dims = tf.reduce_min([max_bin_dims, tf.shape(coords)[1]])
    
    if n_bins is None:
        n_bins = tf.math.pow(tf.cast(elems_per_rs,dtype='float32')/(K/32), 1./tf.cast(max_bin_dims,dtype='float32' ))
        n_bins = tf.cast(n_bins,dtype='int32')
        n_bins = tf.where(n_bins<5,5,n_bins)
        n_bins = tf.where(n_bins>30,30,n_bins)#just a guess
        
    bin_coords = coords
    if bin_coords.shape[-1]>max_bin_dims:
        bin_coords = bin_coords[:,:max_bin_dims]
    
    dbinning,binning, nb, bin_width, nper = BinByCoordinates(bin_coords, row_splits, n_bins=n_bins, name=name)
    
    #if this becomes a bottleneck one could play tricks since nper and bin numbers are predefined
    sorting = tf.argsort(binning)
    
    scoords = tf.gather_nd( coords, sorting[...,tf.newaxis])
    sbinning = tf.gather_nd( binning, sorting[...,tf.newaxis])
    sdbinning = tf.gather_nd( dbinning, sorting[...,tf.newaxis])
    
    if direction is not None:
        direction = tf.gather_nd( direction, sorting[...,tf.newaxis])
    
    #add a leading 0
    bin_boundaries = tf.concat([tf.zeros([1],dtype='int32'), nper],axis=0) #row_splits[0:1]
    # make it row split like
    bin_boundaries = tf.cumsum(bin_boundaries)

    #sanity check
    tf.assert_equal(tf.reduce_max(bin_boundaries), tf.reduce_max(row_splits))
    
    idx,dist = _BinnedSelectKnn(K, scoords,  sbinning, sdbinning, bin_boundaries=bin_boundaries, 
                                n_bins=nb, bin_width=bin_width, tf_compatible=tf_compatible, direction = direction )
    
    #if row_splits.shape[0] is None:
    #    return idx, dist
    #sort back 
    idx = IndexReplacer(idx,sorting)
    dist = tf.scatter_nd(sorting[...,tf.newaxis], dist, tf.shape(dist))
    idx = tf.scatter_nd(sorting[...,tf.newaxis], idx, tf.shape(idx))
    dist = tf.where(idx<0, 0., dist)#safety
    
    if not gl.knn_ops_use_tf_gradients:
        return idx, dist
        
    ncoords = SelectWithDefault(idx, coords, 0.)
    distsq = (ncoords[:,0:1,:]-ncoords)**2
    distsq = tf.reduce_sum(distsq,axis=2)
    distsq = tf.where(idx<0, 0., distsq)
    return idx, distsq


_sknn_grad_op = tf.load_op_library('select_knn_grad.so')
@ops.RegisterGradient("BinnedSelectKnn")
def _BinnedSelectKnnGrad(op, idxgrad, dstgrad):
    
    coords = op.inputs[0]
    indices = op.outputs[0]
    distances = op.outputs[1]

    coord_grad = _sknn_grad_op.SelectKnnGrad(grad_distances=dstgrad, indices=indices, distances=distances, coordinates=coords)

    
    return coord_grad,None,None,None,None,None,None
  
