
#import setGPU
import tensorflow as tf
import numpy as np


rs = tf.constant( [0, 9, 20], dtype='int32')
pred_sid = tf.constant( [0, 0, 1, 2, 1, 
                         1, 3, 4, 4, 
                         0,
                         1, 2, 1, 1, 0,
                         4, 3, 4, 5, 6], dtype='int32')[:,tf.newaxis]
                         

betas = tf.constant([
     [1.,  0.9, 0.1, 0., 0.],
     [0.9, 0.7, 0.,  0., 0. ]
     ])                 

def beta_max_app(betas, eps):
    '''
    beta is non-negative so can use a simplified smooth max approximation
    '''
    return eps * tf.reduce_logsumexp(betas/eps, axis=1)

print(beta_max_app(betas,1e-3))
exit()

from oc_helper_ops import per_rs_segids_to_unique

print(per_rs_segids_to_unique(pred_sid,rs, return_nseg=True))
exit()


def makedata():
    
    rs = tf.constant( [0, 9, 20], dtype='int32')
    istrack = tf.constant( 7*[[0.]]+2*[[1]] + 6*[[0.]]+5*[[1]], dtype='float32')
    feat1 = (istrack + 1.) * 2.
    feat2 = feat1*100.
    
    return istrack, tf.concat([feat1,feat2],axis=-1),  rs

istrack, *other, rs = makedata()

ristrack = tf.RaggedTensor.from_row_splits(istrack,rs)
ristrack = tf.squeeze(ristrack,axis=-1)
rnottrack = ristrack == 0.
ristrack = ristrack != 0.

outnotrack = []
outistrack = []
trs, ntrs = None, None
for a in other:
    
    print(a,rs)
    ra = tf.RaggedTensor.from_row_splits(a,rs)
    nta = tf.ragged.boolean_mask(ra, rnottrack)
    ta  = tf.ragged.boolean_mask(ra, ristrack)
    
    outnotrack.append(nta.values)
    outistrack.append(ta.values)
    
    trs, ntrs = ta.row_splits, nta.row_splits



# add them back
merged = []
mrs = None
for a,b in zip(outnotrack, outistrack):
    
    ra = tf.RaggedTensor.from_row_splits(a,ntrs)
    rb = tf.RaggedTensor.from_row_splits(b,trs)
    m = tf.concat([ra,rb],axis=1)#here defined as axis 1
    
    merged.append(m.values)
    mrs = m.row_splits

print(merged,mrs)

print([merged[i] - other[i] for i in range(len(merged))])
print(mrs,rs)

from GravNetLayersRagged import SplitOffTracks, ConcatRaggedTensors

istrack, *other, rs = makedata()

l_outnotrack, l_outistrack, l_ntrs, l_trs = SplitOffTracks()([istrack, other, rs])

print(l_outnotrack, l_outistrack, l_ntrs, l_trs)


merged, mergers = ConcatRaggedTensors()([l_outnotrack, l_outistrack, l_ntrs, l_trs])


print(merged, mergers)




