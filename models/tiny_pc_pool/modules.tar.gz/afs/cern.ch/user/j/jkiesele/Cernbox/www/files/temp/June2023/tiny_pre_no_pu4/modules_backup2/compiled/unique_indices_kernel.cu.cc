
#if GOOGLE_CUDA
#define EIGEN_USE_GPU
//empty
#endif //GOOGLE_CUDA


